import React, { useState } from 'react';

function App() {
  const [tasks, setTasks] = useState([]);
  const [form, setForm] = useState({ title: '', start: '', finish: '', notes: '' });
  const [editingId, setEditingId] = useState(null);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.title || !form.start || !form.finish) return;
    if (editingId) {
      // Edit existing task
      const res = await fetch(`http://localhost:3001/tasks/${editingId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const updatedTask = await res.json();
      setTasks(tasks.map((t) => (t.id === editingId ? updatedTask : t)));
      setEditingId(null);
    } else {
      // Add new task
      const res = await fetch('http://localhost:3001/tasks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const newTask = await res.json();
      setTasks([...tasks, newTask]);
    }
    setForm({ title: '', start: '', finish: '', notes: '' });
  };

  const handleDelete = async (id) => {
    await fetch(`http://localhost:3001/tasks/${id}`, { method: 'DELETE' });
    setTasks(tasks.filter((t) => t.id !== id));
  };

  const handleEdit = (task) => {
    setForm({
      title: task.title,
      start: task.start,
      finish: task.finish,
      notes: task.notes || '',
    });
    setEditingId(task.id);
  };

  React.useEffect(() => {
    fetch('http://localhost:3001/tasks')
      .then((res) => res.json())
      .then(setTasks);
  }, []);

  return (
    <div style={{ maxWidth: 520, margin: '2rem auto', fontFamily: 'Inter, sans-serif', background: '#f4f6fa', borderRadius: 16, boxShadow: '0 4px 24px rgba(0,0,0,0.06)', padding: 32 }}>
      <h2 style={{ textAlign: 'center', color: '#1976d2', marginBottom: 28, letterSpacing: 1 }}>🗂️ Task Manager</h2>
      <form onSubmit={handleSubmit} style={{ marginBottom: 20 }}>
        <input
          name="title"
          placeholder="Task Title"
          value={form.title}
          onChange={handleChange}
          required
          style={{ marginRight: 8 }}
        />
        <input
          name="start"
          type="datetime-local"
          value={form.start}
          onChange={handleChange}
          required
          style={{ marginRight: 8 }}
        />
        <input
          name="finish"
          type="datetime-local"
          value={form.finish}
          onChange={handleChange}
          required
          style={{ marginRight: 8 }}
        />
        <input
          name="notes"
          placeholder="Notes"
          value={form.notes}
          onChange={handleChange}
          style={{ marginRight: 8 }}
        />
        <button type="submit">{editingId ? 'Update Task' : 'Add Task'}</button>
        {editingId && (
          <button type="button" onClick={() => { setEditingId(null); setForm({ title: '', start: '', finish: '', notes: '' }); }} style={{ marginLeft: 8 }}>
            Cancel
          </button>
        )}
      </form>
      <ul style={{ listStyle: 'none', padding: 0, display: 'grid', gap: 20 }}>
        {tasks.map((task) => (
          <li
            key={task.id}
            style={{
              background: '#fff',
              borderRadius: 12,
              boxShadow: '0 2px 8px rgba(0,0,0,0.08)',
              padding: 20,
              marginBottom: 0,
              border: '1px solid #e0e0e0',
              display: 'flex',
              flexDirection: 'column',
              gap: 6,
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <strong style={{ fontSize: 18 }}>{task.title}</strong>
              <span style={{ fontSize: 12, color: '#888' }}>
                Created: {task.createdAt ? new Date(task.createdAt).toLocaleString() : '—'}
              </span>
            </div>
            <div style={{ color: '#555' }}>Start: <b>{new Date(task.start).toLocaleString()}</b></div>
            <div style={{ color: '#555' }}>Finish: <b>{new Date(task.finish).toLocaleString()}</b></div>
            {task.notes && <div style={{ color: '#333', background: '#f7f7f7', borderRadius: 6, padding: '6px 10px', margin: '6px 0' }}>📝 {task.notes}</div>}
            <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
              <button onClick={() => handleEdit(task)} style={{ flex: 1, background: '#1976d2', color: '#fff', border: 'none', borderRadius: 6, padding: '6px 0', cursor: 'pointer' }}>Edit</button>
              <button onClick={() => handleDelete(task.id)} style={{ flex: 1, background: '#e53935', color: '#fff', border: 'none', borderRadius: 6, padding: '6px 0', cursor: 'pointer' }}>Delete</button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
