# Task Manager Web App

A simple web app to manage tasks with start and finish date/time.

## How to Run

### Server
1. Open a terminal in the `server` folder.
2. Run `npm install` to install dependencies.
3. Run `npm start` to start the backend server (http://localhost:3001).

### Client
1. Open a terminal in the `client` folder.
2. Run `npm install` to install dependencies.
3. Run `npm run dev` to start the frontend (http://localhost:3000).

## Features
- Add tasks with title, start, and finish date/time
- List all tasks
- Delete tasks

---

This app stores tasks in memory (no database).