import express from 'express';
import cors from 'cors';

const app = express();
const PORT = 3001;

app.use(cors());
app.use(express.json());

let tasks = [];
let id = 1;

app.get('/tasks', (req, res) => {
  res.json(tasks);
});

app.post('/tasks', (req, res) => {
  const { title, start, finish, notes } = req.body;
  if (!title || !start || !finish) return res.status(400).json({ error: 'Missing fields' });
  const createdAt = new Date().toISOString();
  const task = { id: id++, title, start, finish, notes: notes || '', createdAt };
  tasks.push(task);
  res.json(task);
});


app.put('/tasks/:id', (req, res) => {
  const taskId = parseInt(req.params.id, 10);
  const { title, start, finish, notes } = req.body;
  const task = tasks.find((t) => t.id === taskId);
  if (!task) return res.status(404).json({ error: 'Task not found' });
  if (title !== undefined) task.title = title;
  if (start !== undefined) task.start = start;
  if (finish !== undefined) task.finish = finish;
  if (notes !== undefined) task.notes = notes;
  // createdAt should not be changed
  res.json(task);
});

app.delete('/tasks/:id', (req, res) => {
  const taskId = parseInt(req.params.id, 10);
  tasks = tasks.filter((t) => t.id !== taskId);
  res.status(204).end();
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
